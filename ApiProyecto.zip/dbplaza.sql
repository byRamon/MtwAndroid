-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 17-04-2020 a las 19:10:52
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbplaza`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidoproductos`
--

CREATE TABLE `pedidoproductos` (
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `idproducto` varchar(36) COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `pedidoproductos`
--

INSERT INTO `pedidoproductos` (`id`, `idproducto`) VALUES
('d00a7e00-800b-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('e44aacab-800b-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('e44aacab-800b-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('e44aacab-800b-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('107a62b6-800c-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('107a62b6-800c-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('107a62b6-800c-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('107a62b6-800c-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('107a62b6-800c-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('76bcb733-8024-11ea-be14-94e979ecb4f6', '26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6'),
('db7e20cc-80cd-11ea-be14-94e979ecb4f6', '9a019ad8-80b8-11ea-be14-94e979ecb4f6');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `idpk` int(11) NOT NULL,
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `usuario` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`idpk`, `id`, `usuario`, `direccion`) VALUES
(61, 'd00a7e00-800b-11ea-be14-94e979ecb4f6', 'ramon', 'Junco 120'),
(62, 'e44aacab-800b-11ea-be14-94e979ecb4f6', 'ramon', 'Junco 120'),
(63, '107a62b6-800c-11ea-be14-94e979ecb4f6', 'ramon', 'Junco 120'),
(64, '76bcb733-8024-11ea-be14-94e979ecb4f6', 'Ramón', 'Junco 120'),
(65, 'db7e20cc-80cd-11ea-be14-94e979ecb4f6', 'Ramón', 'Junco 120');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `idtienda` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `thumbnail` varchar(200) COLLATE utf32_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `idtienda`, `nombre`, `descripcion`, `thumbnail`) VALUES
('id', 'idtienda', 'nombre', 'descripcion', 'thumbnail'),
('26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Jitomate', 'un kilo de jitomate', 'https://ep01.epimg.net/verne/imagenes/2019/05/16/mexico/1557976662_364527_1557978084_noticia_normal.jpg'),
('95d1ae29-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Kilo de cebolla', 'Kilo fresco de cebolla', 'https://ep01.epimg.net/elpais/imagenes/2020/02/17/buenavida/1581937848_519078_1581938419_noticia_normal.jpg'),
('aa16cafe-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Galletas saladas', 'paquete de galletas saladas', 'https://tienda.scorpion.com.mx/media/catalog/product/cache/e4d64343b1bc593f1c5348fe05efa4a6/8/5/8522.jpg'),
('c575b67b-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Pan Blanco', 'Pan blanco bimbo', 'https://www.superama.com.mx/Content/images/products/img_large/0750100011120L.jpg'),
('d9bd85b6-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Madalenas', 'Pan dulce bimbo', 'https://cdn.shopify.com/s/files/1/0706/6309/products/000122995-3m_300x300.jpg'),
('ecc35a2b-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Aceite para cocina', 'Aceite para cocinar', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750103912248L.jpg'),
('fc142ccb-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Kilo de sal de mesa', 'un kilo de sal de mesa yodatada', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00003458702002L.jpg'),
('15484779-80b8-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Jabón para Mano', 'Jabón para lavarse las mano', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750626790800L.jpg'),
('318debb5-80b8-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Jabón de Rop', 'Jabón para Rop', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750119941885L.jpg'),
('4fe0661b-80b8-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Suavizante', 'Suavizante para Ropa ', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750954607544L.jpg'),
('aa68a085-7f97-11ea-a5ea-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de Bistec', 'Kilo fresco de bistec de bola', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020137000000L.jpg'),
('17393c3e-80b7-11ea-be14-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de Molida de res', 'Kilo fresco de molida de res', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020123300000L.jpg'),
('1fc7fda8-80b7-11ea-be14-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de chorizo', 'Kilo fresco de chorizo', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020165000000L.jpg'),
('276d0503-80b7-11ea-be14-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de cocido de res', 'Kilo fresco de cocido de res', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750179166934L.jpg'),
('2e331d63-80b7-11ea-be14-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de chuleta de cerdo', 'Kilo de chuleta de cerdo', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020101000000L.jpg'),
('9a019ad8-80b8-11ea-be14-94e979ecb4f6', '60419a23-7f97-11ea-a5ea-94e979ecb4f6', 'Promoció', 'Medio pollo rostizado con arroz y tortillas con el sabor de casa', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020912300000L.jpg'),
('bb64adc6-80b8-11ea-be14-94e979ecb4f6', '2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Pollo', 'Un pollo rostizado con el sabor de casa y sazón que ya conoc', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020903200000L.jpg'),
('f24cdff3-80b8-11ea-be14-94e979ecb4f6', '2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Sopa de arroz', 'Una porción de deliciosa sopa de arro', 'https://d1uz88p17r663j.cloudfront.net/original/F4547176-811C-6377-B9D8-FF0000673B69-610x360-b-min.png'),
('0df2aec4-80b9-11ea-be14-94e979ecb4f6', '2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Pierna de Pavo', 'Deliciosa pierna de Pavo rostizada ', 'https://esperanza.tr3sco.net/Content/_files/images/product/productos-calientes-4-0855322744164301.png'),
('2a180060-80b9-11ea-be14-94e979ecb4f6', '2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Medio pollo', 'Mitad de sabroso pollo', 'https://t2.rg.ltmcdn.com/es/images/9/7/0/pollo_asado_al_horno_56079_orig.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiendas`
--

CREATE TABLE `tiendas` (
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `telefono` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `ubicacion` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `imagen` varchar(200) COLLATE utf32_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `tiendas`
--

INSERT INTO `tiendas` (`id`, `nombre`, `descripcion`, `telefono`, `ubicacion`, `imagen`) VALUES
('b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Las quince letras', 'Venta de Abarrotes', '4578784512', 'Colonia laureles, torreslanda #27', 'https://definicion.de/wp-content/uploads/2015/05/abarrotes.jpg'),
('ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Carnicería Mi Esperanza', 'La carne mas fresca de la región ', '4611014583', 'CALLE GALAXIA, #146, COLONIA ZONA DE ORO I', 'https://destinonegocio.com/wp-content/uploads/2015/12/ico-destinonegocio-carniceria-istock-getty-images-1030x767.jpg'),
('2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Pollos hermanos', 'Pollo estilo Sinaloa', '4611099310', 'Limonero 531, Girasoles, 38020 Celaya, Gto.', 'https://elmercurio.com.mx/wp-content/uploads/bfi_thumb/1-18-6jpo8gyg0294uammhvo5it5e4txrxz9z9b067l2t4mo.jpeg'),
('60419a23-7f97-11ea-a5ea-94e979ecb4f6', 'Rosticería La Estrella', 'Rosticería La Estrella', '4421584897', 'Quetzalli 503, Alamos, 38024 Celaya, Gto.', 'https://image.freepik.com/vector-gratis/ilustracion-mascota-pollo-parrilla_1594-82.jpg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`idpk`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `idpk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
