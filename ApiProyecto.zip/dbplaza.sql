-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-04-2020 a las 21:00:05
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbplaza`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidoproductos`
--

CREATE TABLE `pedidoproductos` (
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `idproducto` varchar(36) COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `pedidoproductos`
--

INSERT INTO `pedidoproductos` (`id`, `idproducto`) VALUES
('e4b01e5b-7f29-11ea-b2e7-94e979ecb4f6', '3679e7db-7ec7-11ea-b2e7-94e979ecb4f6'),
('e4b01e5b-7f29-11ea-b2e7-94e979ecb4f6', '3679ab73-7ec7-11ea-b2e7-94e979ecb4f6'),
('1c484ba6-7f2a-11ea-b2e7-94e979ecb4f6', '3679e7db-7ec7-11ea-b2e7-94e979ecb4f6'),
('1c484ba6-7f2a-11ea-b2e7-94e979ecb4f6', '3679ab73-7ec7-11ea-b2e7-94e979ecb4f6');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `idpk` int(11) NOT NULL,
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `usuario` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`idpk`, `id`, `usuario`, `direccion`) VALUES
(30, 'e4b01e5b-7f29-11ea-b2e7-94e979ecb4f6', 'usuario2', 'direccion2'),
(31, '1c484ba6-7f2a-11ea-b2e7-94e979ecb4f6', 'usuario2', 'direccion2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `idtienda` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `thumbnail` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `idtienda`, `nombre`, `descripcion`, `thumbnail`) VALUES
('26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Jitomate', 'un kilo de jitomate', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiendas`
--

CREATE TABLE `tiendas` (
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `idtienda` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `telefono` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `ubicacion` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `imagen` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `tiendas`
--

INSERT INTO `tiendas` (`id`, `idtienda`, `nombre`, `descripcion`, `telefono`, `ubicacion`, `imagen`) VALUES
('b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', '', 'Las quince letras', 'Venta de Abarrotes', '4578784512', 'Colonia laureles, torreslanda #27', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`idpk`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `idpk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
